# Волшебная школа медицинских инноваций им. Асклепия

Single-file build. Всё в одном `index.html`, картинка отдельно в `public/map-base.jpg`.

## Запуск

```bash
python3 -m http.server 8080
```

Открыть `http://localhost:8080/`. Через `file://` не работает — Babel standalone не загружает inline-скрипты по file-протоколу в некоторых браузерах.

## Деплой

Просто залить эту папку на любой статический хостинг (Vercel, Netlify, GitHub Pages). Файл `vercel.json` в корне отключает auto-detect фреймворка.

## Структура

```
.
├── index.html         # ВСЁ — HTML + CSS + React + все компоненты в одном файле
├── public/
│   └── map-base.jpg   # карта 3168×1344
└── vercel.json
```
